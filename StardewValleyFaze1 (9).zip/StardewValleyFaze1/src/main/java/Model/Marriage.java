package Model;

public class Marriage
{

}
