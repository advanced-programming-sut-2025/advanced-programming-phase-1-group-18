package enums;

public enum Seasons {
    Spring,
    Summer,
    Fall,
    Winter;
}
