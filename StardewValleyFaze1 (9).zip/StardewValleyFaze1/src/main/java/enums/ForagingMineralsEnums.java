package enums;

public enum ForagingMineralsEnums
{
    Quartz,
    EarthCrystal,
    FrozenTear,
    FireQuartz,
    Emerald,
    Aquamarine,
    Ruby,
    Amethyst,
    Topaz,
    Jade,
    Diamond,
    PrismaticShard,
    CopperOre,
    IronOre,
    GoldOre,
    IridiumOre,
    Coal;

    }
