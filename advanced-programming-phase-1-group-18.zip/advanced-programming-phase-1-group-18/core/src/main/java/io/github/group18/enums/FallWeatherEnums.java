package io.github.group18.enums;

public enum FallWeatherEnums
{
    Sunny,
    Rain,
    Storm;
}
