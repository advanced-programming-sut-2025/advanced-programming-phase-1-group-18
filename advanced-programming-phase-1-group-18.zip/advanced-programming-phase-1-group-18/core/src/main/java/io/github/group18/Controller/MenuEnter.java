package io.github.group18.Controller;

public interface MenuEnter {
    void menuEnter(String menuName);
}
