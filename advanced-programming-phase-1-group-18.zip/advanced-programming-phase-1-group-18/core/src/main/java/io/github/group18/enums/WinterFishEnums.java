package io.github.group18.enums;

public enum WinterFishEnums
{
    MidnightCarp,
    Squid,
    Tuna,
    Perch;
}
