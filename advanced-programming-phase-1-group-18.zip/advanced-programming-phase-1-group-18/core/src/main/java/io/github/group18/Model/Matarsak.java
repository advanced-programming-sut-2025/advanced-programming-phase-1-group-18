package io.github.group18.Model;

import java.util.HashMap;

public class Matarsak
{
    public void adaptMap(HashMap<Integer ,Integer> LakeMap)
    {

    }
}
