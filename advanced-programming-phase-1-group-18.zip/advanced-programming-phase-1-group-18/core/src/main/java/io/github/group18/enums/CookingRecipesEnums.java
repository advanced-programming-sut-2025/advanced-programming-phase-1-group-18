package io.github.group18.enums;

public enum CookingRecipesEnums
{
    Friedegg,
    BakedFish,
    Salad,
    Olmelet,
    pumpkinpie,
    spaghetti,
    pizza,
    Tortilla,
    MakiRoll,
    TripleShotEspresso,
    Cookie,
    hashbrowns,
    pancakes,
    fruitsalad,
    redplate,
    bread,
    salmondinner,
    vegetablemedley,
    farmerslunch,
    survivalburger,
    dishOtheSea,
    seaformPudding,
    minerstreat;
}
