package io.github.group18.Model;

import java.util.HashMap;

public abstract class Tree
{
    protected boolean GhoolPeikar;

    public boolean isGhoolPeikar() {
        return GhoolPeikar;
    }

    public void setGhoolPeikar(boolean ghoolPeikar) {
        this.GhoolPeikar = ghoolPeikar;
    }
}
