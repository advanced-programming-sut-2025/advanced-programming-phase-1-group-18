package io.github.group18.enums;

public enum Seasons {
    Spring,
    Summer,
    Fall,
    Winter;
}
