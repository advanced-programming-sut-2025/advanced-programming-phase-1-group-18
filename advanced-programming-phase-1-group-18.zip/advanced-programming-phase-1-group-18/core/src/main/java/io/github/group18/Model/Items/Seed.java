package io.github.group18.Model.Items;

public class Seed extends Item {

}
