package io.github.group18.Model;
public class Weather
{
    protected String weatherName;
}
