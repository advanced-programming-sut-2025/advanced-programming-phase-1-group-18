package io.github.group18.enums;

public enum SummerFishEnums
{
    Tilapia,
    Dorado,
    Sunfish,
    RainbowTrout;
}
