package io.github.group18.enums;

public enum SpringSeedsEnums {
    CauliFlower,
    Parsnip,
    Potato,
    BlueJazz,
    Tulip;
}
