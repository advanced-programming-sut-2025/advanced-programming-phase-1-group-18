package enums;

public enum WinterWeatherEnums
{
    Snowy;

}
