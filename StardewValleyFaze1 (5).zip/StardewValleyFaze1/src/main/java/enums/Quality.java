package enums;

public enum Quality {
    Normal,
    Silver,
    Gold,
    Iridium;
}