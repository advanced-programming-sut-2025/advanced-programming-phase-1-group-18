package enums;

public enum SummerLegendaryFishEnums
{
    Crimsonfish;
}
