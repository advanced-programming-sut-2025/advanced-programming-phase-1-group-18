package enums;

public enum Tree {
    ApricotTree,
    CherryTree,
    BananaTree,
    MangoTree,
    OrangeTree,
    PeachTree,
    AppleTree,
    PomegranateTree,
    OakTree,
    MapleTree,
    PineTree,
    MahoganyTree,
    MushroomTree,
    MysticTree;
}
