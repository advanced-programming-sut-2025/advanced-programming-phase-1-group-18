package Model.Items;

import java.util.ArrayList;

public class Satl
{
    protected ArrayList<Item> mojodi;
    protected String usage;

    public String getUsage() {
        return usage;
    }

    public void setUsage(String usage) {
        this.usage = usage;
    }
    public ArrayList<Item> getMojodi() {
        return mojodi;
    }

    public void setMojodi(ArrayList<Item> mojodi) {
        this.mojodi = mojodi;
    }
}
