package Model;
public class Cookingrecipe
{
    protected String Name;
    // Getter for Name
    public String getName() {
        return Name;
    }

    // Setter for Name
    public void setName(String Name) {
        this.Name = Name;
    }

}
