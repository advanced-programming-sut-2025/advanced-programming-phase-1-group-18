package Model;

import java.util.HashMap;

public class AllTree extends Tree
{
    public void adaptMap(HashMap<Integer ,Integer> LakeMap)
    {

    }
}
