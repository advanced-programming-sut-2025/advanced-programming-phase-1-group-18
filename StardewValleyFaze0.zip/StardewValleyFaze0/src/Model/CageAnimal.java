package Model;

import java.util.HashMap;

public class CageAnimal extends Animal
{
    protected Cage LivePlace;
    public void adaptMap(HashMap<Integer ,Integer> LakeMap)
    {

    }
}
