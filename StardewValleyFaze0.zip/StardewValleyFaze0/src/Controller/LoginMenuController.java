package Controller;

import Model.Result;

public class LoginMenuController {
    public Result login(String username, String password) {
        return new Result(true, "");
    }

    public Result forgetPassword(String username) {
        return new Result(true, "");
    }

    public String randomPasswordGenerator() {
        return "";
    }

    public void exit() {

    }

    public void showCurrentMenu() {

    }
}
