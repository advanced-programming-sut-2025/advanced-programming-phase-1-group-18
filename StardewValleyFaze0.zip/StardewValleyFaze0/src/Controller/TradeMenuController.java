package Controller;

import Model.Result;



public class TradeMenuController {
    public Result trade(String command)
    {
        return new Result(true, "");
    }
    public void tradeList()
    {

    }
    public Result tradeResponse(String acceptOrReject,int id)
    {

        return new Result(true, "");
    }
    public void tradeHistory()
    {

    }
    public void goBackToGame()
    {

    }



}
