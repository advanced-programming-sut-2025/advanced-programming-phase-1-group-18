package View;

import java.util.Scanner;

public class ProfileMenu extends AppMenu{
public void check(Scanner scanner) {
}
}
