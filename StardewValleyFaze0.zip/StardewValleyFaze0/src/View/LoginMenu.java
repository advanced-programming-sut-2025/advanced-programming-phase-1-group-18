package View;

import java.util.Scanner;

public class LoginMenu extends AppMenu{
public void check(Scanner scanner) {
}
}
