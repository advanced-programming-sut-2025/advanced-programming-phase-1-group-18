package enums;

public enum TavilehAnimalEnums
{
    Cow,
    Sheep,
    Goat,
    Pig;
}
