package Model;

public class CarpentersShopMarket  implements adaptMapMarket{
}
