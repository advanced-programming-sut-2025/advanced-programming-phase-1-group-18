package enums;

public enum SpringWeatherEnum
{
   Sunny,
    Storm,
    Rain;
}
