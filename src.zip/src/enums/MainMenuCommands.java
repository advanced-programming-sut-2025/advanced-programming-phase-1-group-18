package enums;

public class MainMenuCommands {

}
