package enums;

public enum FallSeedsEnums {
    Artichoke,
    Corn,
    Eggplant,
    Pumpkin,
    Sunflower,
    FairyRose;
}
