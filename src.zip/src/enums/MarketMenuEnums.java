package enums;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum MarketMenuEnums {
    SHOWALLPRODUCTS("\\s*show\\s+all\\s+products\\s*"),
    SHOWALLAVAILABLEPRODUCTS("\\s*show\\s+all\\s+available\\s+products\\s*"),
    PURCHASE("\\s*purchase\\s+(?<productName>.+?)\\s+-n\\s+(?<count>\\d+)\\s*"),
    CHEATADD("\\s*cheat\\s+add\\s+(?<count>\\d+)\\s+dollars\\s*"),
    SELL("\\s*sell\\s+(?<productName>.+?)(?:\\s+-n\\s+(?<count>\\d+))?\\s*");

    private final String pattern;

    MarketMenuEnums(String pattern) {
        this.pattern = pattern;
    }

    public Matcher getMather(String input) {
        Matcher matcher = Pattern.compile(this.pattern).matcher(input);

        if (matcher.matches()) {
            return matcher;
        }
        return null;
    }
}
