package enums;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum CarpentersShopCommands
{
    SHOWALLPRODUCTS("\\s*show\\s+all\\s+products\\s*"),
    SHOWALLAVAILABLEPRODUCTS("\\s*show\\s+all\\s+available\\s+products\\s*"),
    BUILDBUILDING("build\\s+-a\\s+([^\\s]+)\\s+-l\\s+\\(\\s*(-?\\d+)\\s*,\\s*(-?\\d+)\\s*\\)");
    private final String pattern;
    CarpentersShopCommands(String pattern) {
        this.pattern = pattern;
    }
    public Matcher getMather(String input) {
        Matcher matcher = Pattern.compile(this.pattern).matcher(input);

        if (matcher.matches()) {
            return matcher;
        }
        return null;
    }
}
