package enums;

public enum SpringSeedsEnums {
    CauliFlower,
    Parsnip,
    Potato,
    BlueJazz,
    Tulip;
}
