package Controller;

import Model.*;

public class RegisterMenuController {
    public Result register(String username, String password, String repassword, String nickname, String email,
            String gender) {
        return new Result(true, "");
    }

    public void exit() {

    }

    public void showCurrentMenu() {

    }

    public Result pickQuestion(int questionNumber, String answer, String reAnswer) {
        return new Result(true, "");
    }
}
