package Controller;

import Model.Result;

public class ProfileMenuController {
    public void exit() {

    }

    public void showCurrentMenu() {

    }

    public Result changeUsername(String newUsername) {
        return new Result(true, "");
    }

    public Result changeNickname(String newNickname) {
        return new Result(true, "");
    }

    public Result changeEmail(String newEmail) {
        return new Result(true, "");
    }

    public Result changePassword(String oldPassword, String newPassword) {
        return new Result(true, "");
    }

    public void userInfo() {

    }
}
