package Controller;

public class MainMenuController {
    public void exit() {

    }

    public void showCurrentMenu() {

    }

    public void logout() {

    }

    public void menuEnter(String menuName) {

    }
}
