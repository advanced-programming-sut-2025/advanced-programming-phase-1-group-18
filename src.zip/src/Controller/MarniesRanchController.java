package Controller;

import Model.*;
import Model.Items.Hay;
import Model.Items.Item;
import Model.Items.MilkPail;
import Model.Items.Shear;
import enums.CageAnimalsEnums;
import enums.MarniesRanchCommands;
import enums.Menu;
import enums.TavilehAnimalEnums;

import java.util.ArrayList;
import java.util.HashMap;

public class MarniesRanchController implements MenuEnter, ShowCurrentMenu, MarketController<Item> {
    @Override
    public HashMap<Item, Integer> getStock() {
        return App.getCurrentGame().getMarniesRanchMarket().getStock();
    }

    public Result purchase(String name, String count) {
        int quantity = -1;
        if (count == null)
        {
            quantity = 1;
        } else
        {
            quantity = Integer.parseInt(count);
        }
        Player currentPlayer = App.getCurrentGame().getPlayers().get(App.getCurrentGame().getIndexPlayerinControl());
        switch (name.toLowerCase()) {
            case "hay":
                boolean validquantity = false;
                for (Item item : App.getCurrentGame().getMarniesRanchMarket().getStock().keySet()) {
                    if (item instanceof Hay && App.getCurrentGame().getMarniesRanchMarket().getStock().get(item) >= quantity) {
                        validquantity = true;
                        if (currentPlayer.getMoney() >= ((Hay) item).getPrice()) {
                            currentPlayer.getInventory().addItem(item, quantity);
                            App.getCurrentGame().getMarniesRanchMarket().removeItem(item, quantity);
                            return new Result(true, "");
                        } else {
                            return new Result(false, "You don't have enough money");
                        }
                    }
                }
                if (!validquantity) {
                    return new Result(false, "Not enough stock in store");
                }
                break;
            case "milk pail":
                boolean validquantity1 = false;
                for (Item item : App.getCurrentGame().getMarniesRanchMarket().getStock().keySet()) {
                    if (item instanceof MilkPail && App.getCurrentGame().getMarniesRanchMarket().getStock().get(item) >= quantity) {
                        validquantity1 = true;
                        if (currentPlayer.getMoney() >= ((MilkPail) item).getPrice()) {
                            currentPlayer.getInventory().addItem(item, quantity);
                            App.getCurrentGame().getMarniesRanchMarket().removeItem(item, quantity);
                            return new Result(true, "");
                        } else {
                            return new Result(false, "You don't have enough money");
                        }
                    }
                }
                if (!validquantity1) {
                    return new Result(false, "Not enough stock in store");
                }
                break;
            case "shears":
                boolean validquantity2 = false;
                for (Item item : App.getCurrentGame().getMarniesRanchMarket().getStock().keySet()) {
                    if (item instanceof Shear && App.getCurrentGame().getMarniesRanchMarket().getStock().get(item) >= quantity) {
                        validquantity2 = true;
                        if (currentPlayer.getMoney() >= ((MilkPail) item).getPrice()) {
                            currentPlayer.getInventory().addItem(item, quantity);
                            App.getCurrentGame().getMarniesRanchMarket().removeItem(item, quantity);
                            return new Result(true, "");
                        } else {
                            return new Result(false, "You don't have enough money");
                        }
                    }
                }
                if (!validquantity2)
                {
                    return new Result(false, "Not enough stock in store");
                }
                break;
            default:
                return new Result(false, "Invalid product name");
        }

        return null;
    }
    public Result buyAnimal(String typeOfAnimal, String nameOfAnimal)
    {
        boolean uniqueName = IsAnimalNameUnique(nameOfAnimal);
        if(!uniqueName)
        {
            return new Result(false, "Your entered animal name is not unique!");
        }
        typeOfAnimal=typeOfAnimal.toLowerCase();

        switch (typeOfAnimal)
        {
            case "chicken":
                if(App.getCurrentGame().getPlayers().get(App.getCurrentGame().getIndexPlayerinControl()).getGold()<800)
                {
                    return new Result(false, "You don't have enough gold");
                }
                else
                {
                    int newGold= App.getCurrentGame().getPlayers().get(App.getCurrentGame().getIndexPlayerinControl()).getGold()-800;
                    App.getCurrentGame().getPlayers().get(App.getCurrentGame().getIndexPlayerinControl()).setGold(newGold);
                    CageAnimal animal = new CageAnimal();
                    animal.setType(String.valueOf(CageAnimalsEnums.Chicken));
                    ArrayList<Animal> animals =  App.getCurrentGame().getPlayers().get(App.getCurrentGame().getIndexPlayerinControl()).getMyBoughtAnimals();
                    animals.add(animal);
                    return new Result(true, "Chicken bought Successfully!");
                }
            case "cow":
                if(App.getCurrentGame().getPlayers().get(App.getCurrentGame().getIndexPlayerinControl()).getGold()<1500)
                {
                    return new Result(false, "You don't have enough gold");
                }
                else
                {
                    int newGold = App.getCurrentGame().getPlayers().get(App.getCurrentGame().getIndexPlayerinControl()).getGold() - 1500;
                    App.getCurrentGame().getPlayers().get(App.getCurrentGame().getIndexPlayerinControl()).setGold(newGold);
                    TavilehAnimal animal = new TavilehAnimal();
                    animal.setType(String.valueOf(TavilehAnimalEnums.Cow));
                    ArrayList<Animal> animals = App.getCurrentGame().getPlayers().get(App.getCurrentGame().getIndexPlayerinControl()).getMyBoughtAnimals();
                    animals.add(animal);
                    return new Result(true, "Cow bought Successfully!");
                }
            case "goat":
                if(App.getCurrentGame().getPlayers().get(App.getCurrentGame().getIndexPlayerinControl()).getGold()<1500)
                {
                    return new Result(false, "You don't have enough gold");
                }
                else
                {
                    int newGold = App.getCurrentGame().getPlayers().get(App.getCurrentGame().getIndexPlayerinControl()).getGold() - 4000;
                    App.getCurrentGame().getPlayers().get(App.getCurrentGame().getIndexPlayerinControl()).setGold(newGold);
                    TavilehAnimal animal = new TavilehAnimal();
                    animal.setType(String.valueOf(TavilehAnimalEnums.Goat));
                    ArrayList<Animal> animals = App.getCurrentGame().getPlayers().get(App.getCurrentGame().getIndexPlayerinControl()).getMyBoughtAnimals();
                    animals.add(animal);
                    return new Result(true, "Goat bought Successfully!");
                }

            case "duck":

            case "sheep":

            case "rabbit":

            case "dinosaur":

            case "pig":

            default:
                return new Result(false, "Invalid animal");
        }

    }


    // for finding animal name
    public boolean  IsAnimalNameUnique(String name)
    {
        ArrayList<Animal> playerAnimals = App.getCurrentGame().getPlayers().get(App.getCurrentGame().getIndexPlayerinControl()).getMyBoughtAnimals();
        for(Animal animal : playerAnimals)
        {
            if(animal.getName().equals(name))
            {
                return false;
            }
        }
        return true;
    }

    public void menuEnter(String menuName) {
        //from markets we can move to gamemenu
        menuName = menuName.toLowerCase();
        switch (menuName) {
            case "gamemenu":
                App.setCurrentMenu(Menu.GameMenu);
                System.out.println("You are now in GameMenu!");
                break;
            default:
                System.out.println("Invalid menu");
                break;
        }
    }
}
