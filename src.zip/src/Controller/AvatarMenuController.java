package Controller;

public class AvatarMenuController {
    public void exit() {

    }

    public void showCurrentMenu() {

    }
}
