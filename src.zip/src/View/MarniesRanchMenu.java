package View;

import Controller.JojaMartController;
import Controller.MarniesRanchController;
import enums.MarketMenuEnums;
import enums.MarniesRanchCommands;

import java.util.Scanner;

public class MarniesRanchMenu extends AppMenu{
    private final MarniesRanchController controller = new MarniesRanchController();

    public void check(Scanner scanner) {
        String input = scanner.nextLine();
        if(MarketMenuEnums.SHOWALLPRODUCTS.getMather(input) != null) {

        }
        else if(MarketMenuEnums.SHOWALLAVAILABLEPRODUCTS.getMather(input) != null) {

        }
        else if(MarketMenuEnums.PURCHASE.getMather(input) != null)
        {

        }
        else if(MarketMenuEnums.CHEATADD.getMather(input) != null) {

        }
        else if(MarketMenuEnums.SELL.getMather(input) != null) {

        }
        else if(MarniesRanchCommands.BUYANIMAL.getMather(input) != null)
        {
            String typeOfAnimal = MarniesRanchCommands.BUYANIMAL.getMather(input).group(1);
            String nameOfAnimal= MarniesRanchCommands.BUYANIMAL.getMather(input).group(2);controller.buyAnimal(typeOfAnimal,nameOfAnimal);
        }
    }
}
