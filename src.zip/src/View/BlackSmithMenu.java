package View;

import Controller.BlackSmithController;
import Controller.GameMenuController;
import enums.GameMenuCommands;
import enums.MarketMenuEnums;

import java.util.Scanner;

public class BlackSmithMenu extends AppMenu
{
    private final BlackSmithController controller = new BlackSmithController();

    public void check(Scanner scanner) {
        String input = scanner.nextLine();
        if(MarketMenuEnums.SHOWALLPRODUCTS.getMather(input) != null) {

        }
        else if(MarketMenuEnums.SHOWALLAVAILABLEPRODUCTS.getMather(input) != null) {

        }
        else if(MarketMenuEnums.PURCHASE.getMather(input) != null) {

        }
        else if(MarketMenuEnums.CHEATADD.getMather(input) != null) {

        }
        else if(MarketMenuEnums.SELL.getMather(input) != null) {

        }
    }
}
