package View;

import Controller.CarpentersShopController;
import Controller.FishShopController;
import enums.MarketMenuEnums;

import java.util.Scanner;

public class FishShopMenu extends AppMenu{
    private final FishShopController controller = new FishShopController();

    public void check(Scanner scanner) {
        String input = scanner.nextLine();
        if(MarketMenuEnums.SHOWALLPRODUCTS.getMather(input) != null) {

        }
        else if(MarketMenuEnums.SHOWALLAVAILABLEPRODUCTS.getMather(input) != null) {

        }
        else if(MarketMenuEnums.PURCHASE.getMather(input) != null) {

        }
        else if(MarketMenuEnums.CHEATADD.getMather(input) != null) {

        }
        else if(MarketMenuEnums.SELL.getMather(input) != null) {

        }
    }
}
