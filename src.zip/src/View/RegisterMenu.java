package View;

import java.util.Scanner;

public class RegisterMenu extends AppMenu{
public void check(Scanner scanner) {
}
}
