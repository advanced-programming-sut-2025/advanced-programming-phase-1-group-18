package Model;
public class Buff
{
    int EnergyIncrease;
    int BuffHours;
    Skill BuffSkill;

}
