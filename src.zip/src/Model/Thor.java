package Model;
import java.util.ArrayList;
public class Thor
{
    ArrayList<Kashi> khordeh;
}



