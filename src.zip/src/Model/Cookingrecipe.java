package Model;
public class Cookingrecipe
{
    String Name;

}
