package Model;

public class Market
{

}
