package Model;
public class Season
{
   String type;
}
