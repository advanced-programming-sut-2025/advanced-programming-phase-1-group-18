package Model;
public class CageAnimal extends Animal
{
    Cage LivePlace;
}
