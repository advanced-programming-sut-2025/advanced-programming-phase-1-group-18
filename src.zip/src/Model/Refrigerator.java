package Model;
import java.util.ArrayList;
import java.util.HashMap;

import Model.Items.*;
public class Refrigerator
{
    ArrayList<Item> FoodCookings;
    HashMap<Item,Integer> Mohtavyaat = new HashMap<>();
}