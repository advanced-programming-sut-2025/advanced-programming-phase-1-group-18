package Model;
import java.util.ArrayList;
import java.util.HashMap;

public class Lake
{

    public void adaptMap(HashMap<Integer ,Integer> LakeMap)
    {

    }

//    protected ArrayList<ArrayList<Kashi>> LakeMap = new ArrayList<>();
//
//    public ArrayList<ArrayList<Kashi>> getLakeMap() {
//        return LakeMap;
//    }
//
//    public void setLakeMap(ArrayList<ArrayList<Kashi>> lakeMap) {
//        this.LakeMap = lakeMap;
//    }
}
