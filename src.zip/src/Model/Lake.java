package Model;
import java.util.ArrayList;

public class Lake
{
    ArrayList<ArrayList<Kashi>> LakeMap = new ArrayList<>();

}
