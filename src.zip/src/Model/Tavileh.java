package Model;
import java.util.ArrayList;

public class Tavileh
{
    String Level;
    ArrayList<TavilehAnimal> TavilehAnimals;
}
