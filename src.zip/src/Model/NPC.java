package Model;

public class NPC {
}
