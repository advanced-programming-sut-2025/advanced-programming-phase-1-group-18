package Model;
public class User
{

    String Username;
    String Password;
    String Email;
    String Gender;
    String NickName;






    User(String Username, String Password, String Email, String Gender, String NickName)
    {
        this.Username = Username;
        this.Password = Password;
        this.Email = Email;
        this.Gender = Gender;
        this.NickName = NickName;
    }

}
