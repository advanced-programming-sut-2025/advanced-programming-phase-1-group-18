package Model;

public class AllTree extends Tree
{
    
}
