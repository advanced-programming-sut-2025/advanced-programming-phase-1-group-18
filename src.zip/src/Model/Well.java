package Model;

import java.util.ArrayList;
import java.util.HashMap;

public class Well
{
    protected static int wellsAmount = 100;
    protected ArrayList<Kashi> insideKashis;
    public static int getWellsAmount() {
        return wellsAmount;
    }

    public static void setWellsAmount(int wellsAmount) {
        Well.wellsAmount = wellsAmount;
    }

    public void adaptMap(ArrayList<Cord> cords)
    {
        this.insideKashis = new ArrayList<>();
        ArrayList<Kashi> kashis = new ArrayList<>();
        for (Cord cord : cords) {
            Kashi kashi = new Kashi();
            kashi.setShokhmZadeh(false);
            kashi.setEnterance(false);
            kashi.setInside(this);
            kashi.setWalkable(false);
            kashis.add(kashi);
            App.getCurrentGame().getMap().get(cord.getX()).set(cord.getY(), kashi);
        }
        this.insideKashis.addAll(kashis);
    }
}
