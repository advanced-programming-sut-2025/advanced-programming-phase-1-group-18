package Model;

import enums.Menu;

import java.util.ArrayList;

public class App {
    public static Season currentseason = new Season();
    private static Menu currentMenu = Menu.RegisterMenu;
    public static Menu getCurrentMenu() {
        return currentMenu;
    }

    public static void setCurrentMenu(Menu currentMenu)
    {
        App.currentMenu = currentMenu;
    }
    

}