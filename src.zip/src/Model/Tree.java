package Model;
public class Tree
{
    Kashi TreesMap = new Kashi();
    boolean GhoolPeikar;
}
