package Model;
public class Skill
{
    String Type;
    int Level;

}
