package Model;

public class ForagingTree extends Tree
{

}
