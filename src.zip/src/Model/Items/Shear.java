package Model.Items;

public class Shear extends Item
{
    int EnergyUsage;
}
