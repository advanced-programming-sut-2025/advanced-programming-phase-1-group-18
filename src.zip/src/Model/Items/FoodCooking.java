package Model.Items;
import java.util.ArrayList;
import java.util.List;

public class FoodCooking extends Item
{
    
    String Name;
    ArrayList<Item> Ingredients;
    int Energy;

}
