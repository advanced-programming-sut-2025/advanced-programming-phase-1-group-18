package Model.Items;
import Model.Buff;
import enums.FoodCookingEnums;

import java.util.ArrayList;

public class FoodCooking extends Item
{

    protected FoodCookingEnums name;
    protected int energy;
    protected int sellPrice;
    protected Buff buff;

    public FoodCookingEnums getName() {
        return name;
    }

    public void setName(FoodCookingEnums name) {
        this.name = name;
    }

    public int getEnergy() {
        return energy;
    }

    public void setEnergy(int energy) {
        this.energy = energy;
    }

    public int getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(int sellPrice) {
        this.sellPrice = sellPrice;
    }

    public Buff getBuff() {
        return buff;
    }

    public void setBuff(Buff buff) {
        this.buff = buff;
    }
}
