package Model.Items;
import java.util.ArrayList;
public class AllCrop extends Crop
{
    Source source;
    int DaysGrowCounter;
    ArrayList<Integer> Stages;
    int TotalHarvestTime;
    boolean One_Time;
    int Regrowth_Time;
    boolean Can_Become_Giant;



    //Seed Crop Tree Problem //
    //Motaghayer baraye Aab Dehi//
}
