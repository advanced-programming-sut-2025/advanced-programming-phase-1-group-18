package Model.Items;

public class Source extends Item
{
    String Name;
}
