package Model.Items;

public class TrashCan extends Item
{
    String Jens;
    int EnergyUsage;
}
