package Model.Items;

public class Axe extends Item
{
    String Jens;
    int EnergyUsage;
}
