package Model.Items;

public class MilkPail extends Item
{
    int EnergyUsage;
}
