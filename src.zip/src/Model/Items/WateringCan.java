package Model.Items;

public class WateringCan extends Item
{
    String Jens;
    int EnergyUsage;
}





