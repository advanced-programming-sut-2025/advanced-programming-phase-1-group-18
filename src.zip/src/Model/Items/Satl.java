package Model.Items;

import java.util.ArrayList;

public class Satl
{
    ArrayList<Item> mojodi;
}
