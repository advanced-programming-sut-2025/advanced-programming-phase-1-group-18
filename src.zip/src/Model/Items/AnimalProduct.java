package Model.Items;

public class AnimalProduct extends Item
{
    String Name;
    String Jens;
    int SellPrice;

}
