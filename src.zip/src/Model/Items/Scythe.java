package Model.Items;

public class Scythe extends Item
{
    int EnergyUsage;
}
