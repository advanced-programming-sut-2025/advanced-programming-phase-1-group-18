package Model.Items;

import java.util.ArrayList;

public class CraftingItem extends Item
{
    String Name;
    ArrayList<Item> Ingredients ;
    int SellPrice;


}
