package Model.Items;
public class Pickaxe extends Item
{
    String Jens;
    int EnergyUsage;
}
