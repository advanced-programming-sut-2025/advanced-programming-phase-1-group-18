package Model.Items;

public class Hoe extends Item
{
    String Jens;
    int EnergyUsage;
}
