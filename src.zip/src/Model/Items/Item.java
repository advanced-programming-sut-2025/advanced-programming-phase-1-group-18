package Model.Items;

public class Item
{
    protected String Type;

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        this.Type = type;
    }
}
