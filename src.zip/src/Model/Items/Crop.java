package Model.Items;

public class Crop extends Item
{

   String Name;
   int BaseSellPrice;
   int Energy;

}
