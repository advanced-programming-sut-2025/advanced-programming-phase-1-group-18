package Model.Items;

public class FishingPole extends Item
{
    String Jens;
    int EnergyUsage;
}
