package Model;
import java.util.ArrayList;

public class Player extends User
{

    int Energy;
    Farm myFarm;
    boolean UnlimitedEnergy;
    Skill FarmingSkill;
    Skill ExtractionSkill;
    Skill ForagingSkill;
    Skill FishingSkill;
    Buff FoodBuff;
    ArrayList<Cookingrecipe> Cookingrecipes;
    ArrayList<Cookingrecipe> Craftingrecipes;

    ArrayList<Cage> Cages;

    ArrayList<Tavileh> Tavilehs;
    
    Player(String Username, String Password, String Email, String Gender, String NickName)
    {
        super(Username, Password, Email, Gender, NickName);
    }

    public void faintController(){
        
    }

}
