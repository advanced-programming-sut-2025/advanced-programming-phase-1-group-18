package Model;
import java.util.ArrayList;
import java.util.HashMap;

public class Quarry
{
//    protected  ArrayList<ArrayList<Kashi>> QuarryMap = new ArrayList<>();
//    public void setterQuarry()
//    {
//        System.out.println("Quarry Setter");
//    }
//
//    public ArrayList<ArrayList<Kashi>> getQuarryMap() {
//        return QuarryMap;
//    }

    //    public void setQuarryMap(ArrayList<ArrayList<Kashi>> quarryMap) {
//        this.QuarryMap = quarryMap;
//    }
    public void adaptMap(HashMap<Integer ,Integer> LakeMap)
    {

    }
}
