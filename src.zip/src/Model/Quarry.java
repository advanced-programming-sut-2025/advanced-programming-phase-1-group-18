package Model;
import java.util.ArrayList;

public class Quarry
{
    ArrayList<ArrayList<Kashi>> QuarryMap = new ArrayList<>();
    public void setterQuarry()
    {
        System.out.println("Quarry Setter");
    }
}
