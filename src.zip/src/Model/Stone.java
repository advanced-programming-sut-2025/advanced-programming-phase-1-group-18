package Model;
public class Stone
{

    int Price;
    Season Season = new Season();
    public void changeseason()
    {

    }
}
