package Model;
public class TavilehAnimal extends Animal
{
    Tavileh LivePlace;
}
