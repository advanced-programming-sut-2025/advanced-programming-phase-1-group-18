package Model;
import java.util.ArrayList;

import Model.Items.AnimalProduct;

public class Animal
{
   String Name;
   int Friendship;
   boolean Navazesh;
   boolean Taghzieh;

   int Price;
   ArrayList<AnimalProduct> AnimalProducts;
}
