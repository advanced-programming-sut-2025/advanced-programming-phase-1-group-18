package Model;
import java.util.ArrayList;
import java.util.HashMap;

public class Cage
{
    protected int cageAmounts = 100;

    public int getCageAmounts()
    {
        return cageAmounts;
    }

    public void setCageAmounts(int cageAmounts)
    {
        this.cageAmounts = cageAmounts;
    }

    // make it true when Cage
    protected boolean Status = false;
    protected final int MaxCapacity =4;
    protected String Level;
    protected ArrayList<CageAnimal> CageAnimals;
    protected ArrayList<Kashi> insideKashis;

    public ArrayList<Kashi> getInsideKashis() {
        return insideKashis;
    }

    public void setInsideKashis(ArrayList<Kashi> insideKashis) {
        this.insideKashis = insideKashis;
    }

    public String getLevel() {
        return Level;
    }

    public void setLevel(String level) {
        Level = level;
    }

    public ArrayList<CageAnimal> getCageAnimals() {
        return CageAnimals;
    }

    public void setCageAnimals(ArrayList<CageAnimal> cageAnimals) {
        CageAnimals = cageAnimals;
    }

    // max capacity of simple Cage
    public int getMaxCapacity() {
        return MaxCapacity;
    }

    public void setStatus(boolean status) {
        Status = status;
    }

    public void adaptMap(ArrayList<Cord> cords)
    {

        this.insideKashis = new ArrayList<>();
        ArrayList<Kashi> kashis = new ArrayList<>();
        for (Cord cord : cords) {
            Kashi kashi = new Kashi();
            kashi.setShokhmZadeh(false);
            kashi.setEnterance(false);
            kashi.setInside(this);
            kashi.setWalkable(false);
            kashis.add(kashi);
            App.getCurrentGame().getMap().get(cord.getX()).set(cord.getY(), kashi);
        }
        this.insideKashis.addAll(kashis);
    }
}
