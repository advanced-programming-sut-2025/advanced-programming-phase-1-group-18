package Model;
import java.util.ArrayList;

public class Cage
{
    String Level;
    ArrayList<CageAnimal> CageAnimals;
}
