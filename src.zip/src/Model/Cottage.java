package Model;
import java.util.ArrayList;

public class Cottage
{
    ArrayList<ArrayList<Kashi>> CottageMap = new ArrayList<>();
    Kashi Enterance = new Kashi();

}
