package Model;
import java.util.ArrayList;

public class GreenHouse
{
    boolean Status= false;
    ArrayList<Matarsak> Matarsaks= new ArrayList<>();
}
