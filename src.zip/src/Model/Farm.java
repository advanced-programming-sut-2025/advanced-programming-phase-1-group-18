package Model;
import java.util.ArrayList;

public class Farm
{





    ArrayList<ArrayList<Kashi>> Map= new ArrayList<>();
    ArrayList<Lake>  Lakes= new ArrayList<>();
    GreenHouse myGreenHouse= new GreenHouse();
    Cottage myCottage= new Cottage();
    Quarry myQuarry= new Quarry();
    public void mapCreator (){

    }
}
