package Model;
public class DateTime
{
    int Hour;
    int Day;

}
