package Model;
public class Craftingrecipe
{
    String Name;

}
