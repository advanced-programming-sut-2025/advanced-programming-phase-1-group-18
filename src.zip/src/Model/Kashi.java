package Model;
public class Kashi
{
    boolean ShokhmZadeh;
    int x;
    int y;
}
