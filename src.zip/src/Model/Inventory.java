package Model;
import java.util.ArrayList;
import java.util.HashMap;

import Model.Items.Item;
public class Inventory
{
    int MaxQuantity;
    String Type;
    HashMap<Item,Integer> Items = new HashMap<>();

}
