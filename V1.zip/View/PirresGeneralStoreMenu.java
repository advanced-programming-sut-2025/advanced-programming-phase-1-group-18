package View;

public class PirresGeneralStoreMenu {
    
}
