package View;

import Controller.LoginMenuController;
import enums.LoginMenuCommands;

import java.util.Scanner;

public class LoginMenu extends AppMenu{
    private final LoginMenuController controller = new LoginMenuController();
    @Override
    public void check(Scanner scanner)
    {
        String input = scanner.nextLine();
        //Matcher goToMenu = MainMenuCommands.GO_TO_MENU.getMatcher(input);
        if (LoginMenuCommands.Login.getMatcher(input) != null) {
            String username = LoginMenuCommands.Login.getMatcher(input).group("username");
            String password = LoginMenuCommands.Login.getMatcher(input).group("password");
            String stayLoggedIn = LoginMenuCommands.Login.getMatcher(input).group("stayLoggedIn");
            controller.login(username, password, stayLoggedIn);
        } else if (LoginMenuCommands.MenuExit.getMatcher(input) != null) {
            controller.exit();
        } else if (LoginMenuCommands.MenuEnter.getMatcher(input) != null) {
            String menuName = LoginMenuCommands.MenuEnter.getMatcher(input).group(1);
            controller.menuEnter(menuName);
        } else if (LoginMenuCommands.ShowCurrentMenu.getMatcher(input) != null) {
            controller.showCurrentMenu();
        } else if (LoginMenuCommands.ForgetPassword.getMatcher(input) != null) {
            String username = LoginMenuCommands.Login.getMatcher(input).group("username");
            controller.forgetPassword(username, scanner);
        } else {
            System.out.println("invalid command");
        }
    }
}