package Controller;


import Model.App;
import Model.Result;
import Model.User;
import enums.LoginMenuCommands;
import enums.Menu;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class LoginMenuController implements MenuEnter, ShowCurrentMenu{

    public Result login(String username, String password, String stayLoggedIn) {
        if (username.isEmpty())
        {
            return new Result(false, "you should enter username");
        }
        if (password.isEmpty()) {
            return new Result(false, "you should enter password");
        }
        if (findUserByUsername(username) != null) {
            return new Result(false, "user already exist");
        }
        User user = findUserByUsername(username);
        if (!user.getPassword().equals(password)) {
            return new Result(false, "wrong password");
        }
        else{
            user.setStayLoggedIn(!stayLoggedIn.isEmpty());
            App.setCurrentuser(user);
            App.setCurrentMenu(Menu.MainMenu);
            return new Result(true, "user logged successfully");
        }
    }

    public Result forgetPassword(String username, Scanner scanner) {
        User user = findUserByUsername(username);
        if (user == null) {
            return new Result(false, "user not found");
        }
        String answerCommand = scanner.nextLine();
        if (LoginMenuCommands.Answer.getMatcher(answerCommand) != null) {
            String answer = LoginMenuCommands.Answer.getMatcher(answerCommand).group("answer");
            //handling answering task ...
        }
        else {
            return new Result(false, "wrong answer format");
        }
        return null;
    }

    public void exit() {
        System.exit(0);
    }

    public void menuEnter(String menuName) {
        //from loginmenu we can move to registermenu
        menuName = menuName.toLowerCase();
        switch(menuName)
        {
            case "registermenu":
                App.setCurrentMenu(Menu.RegisterMenu);
                System.out.println("You are now in RegisterMenu!");
                break;
            default:
                System.out.println("Invalid menu");
                break;
        }
    }

    public User findUserByUsername (String username){
        for(User user : App.getUsers()){
            if(user.getUsername().equals(username)){
                return user;
            }
        }
        return null;
    }

}
