package Model.Items;

public class ForagingCrop extends Crop
{
    //
}
