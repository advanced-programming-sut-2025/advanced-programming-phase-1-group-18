package Model.Items;

public class ForagingSeed extends Seed
{

}
