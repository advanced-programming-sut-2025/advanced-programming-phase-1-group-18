package enums;

public enum FallFishEnums
{
    Salmon,
    Sardine,
    Shad,
    BlueDiscus;


}
