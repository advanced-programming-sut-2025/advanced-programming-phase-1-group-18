package enums;

public enum ForagingTreesEnums
{
    Name,
    Acorns,
    MapleSeeds,
    PineCones,
    MahoganySeeds,
    MushroomTreeSeeds;
}
