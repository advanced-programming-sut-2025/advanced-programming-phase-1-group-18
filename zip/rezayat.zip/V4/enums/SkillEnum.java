package enums;

public enum SkillEnum {
    FarmingSkill,
    MiningSkill,
    ForagingSkill,
    FishingSkill;
}