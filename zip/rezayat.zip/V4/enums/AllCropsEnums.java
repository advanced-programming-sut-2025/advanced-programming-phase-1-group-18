package enums;

import java.util.EnumSet;
import java.util.Set;

public enum AllCropsEnums {
    BlueJazz(EnumSet.of(ForagingSeedsEnums.JazzSeeds)),
    Carrot(EnumSet.of(ForagingSeedsEnums.CarrotSeeds)),
    CauliFlower(EnumSet.of(ForagingSeedsEnums.CauliflowerSeeds)),
    CoffeeBean(EnumSet.of(ForagingSeedsEnums.CoffeeBean)),
    Garlic(EnumSet.of(ForagingSeedsEnums.GarlicSeeds)),
    GreenBean(EnumSet.of(ForagingSeedsEnums.BeanStarter)),
    Kale(EnumSet.of(ForagingSeedsEnums.KaleSeeds)),
    Parsnip(EnumSet.of(ForagingSeedsEnums.ParsnipSeeds)),
    Potato(EnumSet.of(ForagingSeedsEnums.PotatoSeeds)),
    Rhubarb(EnumSet.of(ForagingSeedsEnums.RhubarbSeeds)),
    StrawBerry(EnumSet.of(ForagingSeedsEnums.StrawberrySeeds)),
    Tulip(EnumSet.of(ForagingSeedsEnums.TulipBulb)),
    UnmilledRice(EnumSet.of(ForagingSeedsEnums.RiceShoot)),
    BlueBerry(EnumSet.of(ForagingSeedsEnums.BlueberrySeeds)),
    Corn(EnumSet.of(ForagingSeedsEnums.CornSeeds)),
    Hops(EnumSet.of(ForagingSeedsEnums.HopsStarter)),
    HotPepper(EnumSet.of(ForagingSeedsEnums.PepperSeeds)),
    Melon(EnumSet.of(ForagingSeedsEnums.MelonSeeds)),
    Poppy(EnumSet.of(ForagingSeedsEnums.PoppySeeds)),
    Radish(EnumSet.of(ForagingSeedsEnums.RadishSeeds)),
    RedCabbage(EnumSet.of(ForagingSeedsEnums.RedCabbageSeeds)),
    StarFruit(EnumSet.of(ForagingSeedsEnums.StarfruitSeeds)),
    SummerSpangle(EnumSet.of(ForagingSeedsEnums.SpangleSeeds)),
    SummerSquash(EnumSet.of(ForagingSeedsEnums.SummerSquasSeeds)),
    SunFlower(EnumSet.of(ForagingSeedsEnums.SunflowerSeeds)),
    Tomato(EnumSet.of(ForagingSeedsEnums.TomatoSeeds)),
    Wheat(EnumSet.of(ForagingSeedsEnums.WheatSeeds)),
    Amaranth(EnumSet.of(ForagingSeedsEnums.AmaranthSeeds)),
    Artichoke(EnumSet.of(ForagingSeedsEnums.ArtichokeSeeds)),
    Beet(EnumSet.of(ForagingSeedsEnums.BeetSeeds)),
    Bokchoy(EnumSet.of(ForagingSeedsEnums.BokChoySeeds)),
    Broccoli(EnumSet.of(ForagingSeedsEnums.BroccoliSeeds)),
    CramBerries(EnumSet.of(ForagingSeedsEnums.CranberrySeeds)),
    EggPlant(EnumSet.of(ForagingSeedsEnums.EggplantSeeds)),
    FairyRose(EnumSet.of(ForagingSeedsEnums.FairySeeds)),
    Grape(EnumSet.of(ForagingSeedsEnums.GrapeStarter)),
    Pumpkin(EnumSet.of(ForagingSeedsEnums.PumpkinSeeds)),
    Yam(EnumSet.of(ForagingSeedsEnums.YamSeeds)),
    SweetGemBerry(EnumSet.of(ForagingSeedsEnums.RareSeed)),
    PowderMelon(EnumSet.of(ForagingSeedsEnums.PowdermelonSeeds)),
    AncientFruit(EnumSet.of(ForagingSeedsEnums.AncientSeeds));

    private final ForagingSeedsEnums seedSet;

    AllCropsEnums(ForagingSeedsEnums seedSet) {
        this.seedSet = seedSet;
    }

    public ForagingSeedsEnums getSeedSet() {
        return seedSet;
    }
}
