package Model.Items;

public class Source extends Item
{
    protected String Name;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }
}
