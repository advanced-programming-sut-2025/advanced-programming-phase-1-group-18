package Model;

public class Friendship
{
    protected int friendshipLevel;
}
