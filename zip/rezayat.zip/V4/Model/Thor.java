package Model;
import java.util.ArrayList;
public class Thor
{
    protected ArrayList<Kashi> khordeh;

    public ArrayList<Kashi> getKhordeh() {
        return khordeh;
    }

    public void setKhordeh(ArrayList<Kashi> khordeh) {
        this.khordeh = khordeh;
    }
}



