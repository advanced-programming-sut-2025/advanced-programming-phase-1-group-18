package Model;

import enums.Menu;

import java.util.ArrayList;

public class App {
    protected static ArrayList<User> users = new ArrayList<>();
    protected static Season currentseason = new Season();
    protected static Menu currentMenu = Menu.RegisterMenu;
    protected static DateTime currentDateTime = new DateTime();

    public static DateTime getCurrentDateTime() {
        return currentDateTime;
    }

    public static void setCurrentDateTime(DateTime currentDateTime) {
        App.currentDateTime = currentDateTime;
    }

    public static Menu getCurrentMenu() {
        return currentMenu;
    }

    public static void setCurrentMenu(Menu currentMenu)
    {
        App.currentMenu = currentMenu;
    }

    public static ArrayList<User> getUsers() {
        return users;
    }

    public static void setUsers(ArrayList<User> users) {
        App.users = users;
    }

    public static Season getCurrentseason() {
        return currentseason;
    }

    public static void setCurrentseason(Season currentseason) {
        App.currentseason = currentseason;
    }
}