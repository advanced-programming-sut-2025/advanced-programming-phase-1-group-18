package Model;

import java.util.HashMap;

public class Market
{
    public void adaptMap(HashMap<Integer ,Integer> LakeMap)
    {

    }
}
