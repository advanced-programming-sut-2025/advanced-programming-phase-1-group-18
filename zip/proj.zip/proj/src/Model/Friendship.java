package Model;

public class Friendship
{

}
