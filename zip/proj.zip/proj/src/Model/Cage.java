package Model;
import java.util.ArrayList;
import java.util.HashMap;

public class Cage
{
    protected String Level;
    protected ArrayList<CageAnimal> CageAnimals;
    public void adaptMap(HashMap<Integer ,Integer> LakeMap)
    {

    }
}
