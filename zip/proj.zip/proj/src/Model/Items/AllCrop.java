package Model.Items;
import java.util.ArrayList;
public class AllCrop extends Crop
{
    protected Source source;
    protected int DaysGrowCounter;
    protected ArrayList<Integer> Stages;
    protected int TotalHarvestTime;
    protected boolean One_Time;
    protected int Regrowth_Time;
    protected boolean Can_Become_Giant;

    public Source getSource() {
        return source;
    }

    public void setSource(Source source) {
        this.source = source;
    }

    public int getDaysGrowCounter() {
        return DaysGrowCounter;
    }

    public void setDaysGrowCounter(int daysGrowCounter) {
        this.DaysGrowCounter = daysGrowCounter;
    }

    public ArrayList<Integer> getStages() {
        return Stages;
    }

    public void setStages(ArrayList<Integer> stages) {
        this.Stages = stages;
    }

    public int getTotalHarvestTime() {
        return TotalHarvestTime;
    }

    public void setTotalHarvestTime(int totalHarvestTime) {
        this.TotalHarvestTime = totalHarvestTime;
    }

    public boolean isOne_Time() {
        return One_Time;
    }

    public void setOne_Time(boolean one_Time) {
        this.One_Time = one_Time;
    }

    public int getRegrowth_Time() {
        return Regrowth_Time;
    }

    public void setRegrowth_Time(int regrowth_Time) {
        this.Regrowth_Time = regrowth_Time;
    }

    public boolean isCan_Become_Giant() {
        return Can_Become_Giant;
    }

    public void setCan_Become_Giant(boolean can_Become_Giant) {
        this.Can_Become_Giant = can_Become_Giant;
    }
//Seed Crop Tree Problem //
    //Motaghayer baraye Aab Dehi//
}
