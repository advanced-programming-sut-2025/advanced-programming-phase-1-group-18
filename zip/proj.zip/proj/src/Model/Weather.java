package Model;
public class Weather
{
    
}
