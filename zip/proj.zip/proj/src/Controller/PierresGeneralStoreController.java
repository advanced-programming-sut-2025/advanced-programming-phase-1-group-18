package Controller;

import Model.Result;

public class PierresGeneralStoreController {
    public void showAllProducts() {

    }

    public void showAllAvailableProduct() {

    }

    public Result purchase(String Name, int count) {
        return new Result(true, "");
    }

    public Result cheatAdd(int count) {
        return new Result(true, "");
    }
}
