package Controller;

import Model.Player;
import Model.Result;

public class TradeMenuController {
    public Result Trade(Player palayer1, Player player2){
        return new Result(true, "");
    }
}
