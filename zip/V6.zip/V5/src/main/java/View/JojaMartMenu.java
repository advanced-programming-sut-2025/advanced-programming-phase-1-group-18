package View;

import Controller.FishShopController;
import Controller.JojaMartController;
import Model.App;
import enums.MarketMenuEnums;

import java.util.Scanner;

public class JojaMartMenu extends AppMenu
{
    private final JojaMartController controller = new JojaMartController();

    public void check(Scanner scanner) {
        String input = scanner.nextLine();
        if(MarketMenuEnums.SHOWALLPRODUCTS.getMather(input) != null) {

        }
        else if(MarketMenuEnums.SHOWALLAVAILABLEPRODUCTS.getMather(input) != null) {

        }
        else if(MarketMenuEnums.PURCHASE.getMather(input) != null) {

        }
        else if(MarketMenuEnums.CHEATADD.getMather(input) != null) {

        }
        else if(MarketMenuEnums.SELL.getMather(input) != null) {

        }
    }
}
