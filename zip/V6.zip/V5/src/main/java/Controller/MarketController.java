package Controller;

import Model.Result;

public interface MarketController {
    default void showAllProducts() {

    }

    default void showAllAvailableProduct() {

    }

    default Result purchase(String Name, int count) {
        return new Result(true, "");
    }

    default Result cheatAdd(int count) {
        return new Result(true, "");
    }
}
