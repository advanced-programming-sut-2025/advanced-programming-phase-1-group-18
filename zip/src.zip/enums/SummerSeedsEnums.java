package enums;

public enum SummerSeedsEnums {
    Corn,
    HotPepper,
    Radish,
    Wheat,
    Poppy,
    Sunflower,
    SummerSpangle;
}
