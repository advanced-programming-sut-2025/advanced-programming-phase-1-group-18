package Controller;

public interface MenuEnter {
    void menuEnter(String menuName);
}
