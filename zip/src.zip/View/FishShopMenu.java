package View;

public class FishShopMenu {
    
}
