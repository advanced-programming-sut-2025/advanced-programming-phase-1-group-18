package Model.Items;

public class Fish
{

}
