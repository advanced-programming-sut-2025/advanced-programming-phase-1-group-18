package Model;

import java.util.HashMap;

public class ForagingTree extends Tree
{
    public void adaptMap(HashMap<Integer ,Integer> LakeMap)
    {

    }
}
