package Model;
public class Season
{
   protected String type;

   public String getType() {
      return type;
   }

   public void setType(String type) {
      this.type = type;
   }
}
