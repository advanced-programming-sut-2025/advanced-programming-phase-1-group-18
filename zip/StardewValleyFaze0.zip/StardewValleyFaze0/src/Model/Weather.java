package Model;
public class Weather
{
    protected String weatherName;
}
