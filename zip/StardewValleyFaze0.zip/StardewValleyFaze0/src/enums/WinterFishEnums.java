package enums;

public enum WinterFishEnums
{
    MidnightCarp,
    Squid,
    Tuna,
    Perch;
}
