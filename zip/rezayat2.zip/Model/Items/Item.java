package Model.Items;

public class Item
{
    protected String name;  // یا public

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
