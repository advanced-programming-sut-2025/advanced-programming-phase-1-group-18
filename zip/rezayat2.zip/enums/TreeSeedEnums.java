package enums;

public enum TreeSeedEnums {
    ApricotSapling,
    CherrySapling,
    BananaSapling,
    MangoSapling,
    OrangeSapling,
    PeachSapling,
    AppleSapling,
    PomegranateSapling,
    Acorns,
    MapleSeeds,
    PineCones,
    MahoganySeeds,
    MushroomTreeSeeds,
    MysticTreeSeeds;
}
