package View;

import java.util.Scanner;

public class ExitMenu extends AppMenu {
    public void check(Scanner scanner) {
    }
}
