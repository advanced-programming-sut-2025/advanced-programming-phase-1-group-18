package enums;
import Model.*;
public enum ForagingTreesEnums
{
    Acorns,
    MapleSeeds,
    PineCones,
    MahoganySeeds,
    MushroomTreeSeeds;
}
