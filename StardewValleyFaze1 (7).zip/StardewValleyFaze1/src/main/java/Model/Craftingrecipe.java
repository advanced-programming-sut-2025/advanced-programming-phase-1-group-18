package Model;
public class Craftingrecipe
{
    protected String Name;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

}
