package View;

public class MarniesRanchMenu {
    
}
