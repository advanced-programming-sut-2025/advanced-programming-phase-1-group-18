package io.github.group18.Model;

import io.github.group18.Model.Items.Item;

import java.util.ArrayList;
import java.util.HashMap;

public class Market
{
protected ArrayList<Item> products;
    public void adaptMap(HashMap<Integer ,Integer> LakeMap)
    {

    }
}
