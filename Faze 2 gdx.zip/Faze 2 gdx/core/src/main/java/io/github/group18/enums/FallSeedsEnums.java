package io.github.group18.enums;

public enum FallSeedsEnums {
    Artichoke,
    Corn,
    Eggplant,
    Pumpkin,
    Sunflower,
    FairyRose;
}
