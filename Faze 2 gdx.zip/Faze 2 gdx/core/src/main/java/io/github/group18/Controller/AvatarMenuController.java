package io.github.group18.Controller;

public class AvatarMenuController implements MenuEnter, ShowCurrentMenu {

    public void menuEnter(String menuName) {
        //TODO
    }

}
