package io.github.group18.enums;

public enum TavilehAnimalEnums
{
    Cow,
    Sheep,
    Goat,
    Pig;
}
