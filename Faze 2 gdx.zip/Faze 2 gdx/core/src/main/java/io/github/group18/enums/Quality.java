package io.github.group18.enums;

public enum Quality {
    Normal,
    Silver,
    Gold,
    Iridium;
}
