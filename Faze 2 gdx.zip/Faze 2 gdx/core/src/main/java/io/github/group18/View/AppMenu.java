package io.github.group18.View;

import java.util.Scanner;

public abstract class AppMenu {
    public abstract void check(Scanner scanner);
}
