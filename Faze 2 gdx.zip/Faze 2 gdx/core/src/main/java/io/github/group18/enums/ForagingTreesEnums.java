package io.github.group18.enums;
public enum ForagingTreesEnums
{
    Acorns,
    MapleSeeds,
    PineCones,
    MahoganySeeds,
    MushroomTreeSeeds;
}
