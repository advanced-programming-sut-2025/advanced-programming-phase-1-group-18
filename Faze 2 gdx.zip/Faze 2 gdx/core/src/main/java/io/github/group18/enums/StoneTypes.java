package io.github.group18.enums;

public enum StoneTypes {
    REGULAR,
    COPPER,
    IRON,
    GOLD,
    IRIDIUM;
}
