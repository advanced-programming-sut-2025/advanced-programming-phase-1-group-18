package io.github.group18.enums;

public enum SummerSeedsEnums {
    Corn,
    HotPepper,
    Radish,
    Wheat,
    Poppy,
    Sunflower,
    SummerSpangle;
}
