package io.github.group18.Model.Items;

public interface Price {
    public int getCorrectPrice();
}
