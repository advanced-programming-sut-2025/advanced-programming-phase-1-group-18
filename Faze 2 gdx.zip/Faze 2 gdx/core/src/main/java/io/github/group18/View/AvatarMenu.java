package io.github.group18.View;

import java.util.Scanner;

public class AvatarMenu extends AppMenu{
public void check(Scanner scanner) {
}
}
