package io.github.group18.enums;

public enum NPCEnums {
    SEBASTIAN,
    ABIGAIL,
    HARVEY,
    LEAH,
    ROBIN;
}
