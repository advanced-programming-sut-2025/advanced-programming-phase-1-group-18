package io.github.group18.Model;

public interface Name {
    public String getCorrectName();
}
