package io.githubgroup18.Model;
public class Weather
{
    protected String weatherName;
}
