package io.githubgroup18.enums;

public enum CageAnimalsEnums
{
    Chicken,
    Duck,
    Rabbit,
    Dinosaur,
}
