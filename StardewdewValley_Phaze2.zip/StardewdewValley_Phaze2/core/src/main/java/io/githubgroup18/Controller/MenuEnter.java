package io.githubgroup18.Controller;

public interface MenuEnter {
    void menuEnter(String menuName);
}
