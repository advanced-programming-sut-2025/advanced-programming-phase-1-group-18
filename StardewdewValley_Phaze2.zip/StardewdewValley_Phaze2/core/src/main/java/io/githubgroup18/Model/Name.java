package io.githubgroup18.Model;
public interface Name {
    public String getCorrectName();
}
