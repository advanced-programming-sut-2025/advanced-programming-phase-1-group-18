package io.githubgroup18.enums;

public enum NPCEnums {
    SEBASTIAN,
    ABIGAIL,
    HARVEY,
    LEAH,
    ROBIN;
}
