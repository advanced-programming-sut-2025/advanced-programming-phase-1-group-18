package io.githubgroup18.enums;

public enum SpringWeatherEnum
{
   Sunny,
    Storm,
    Rain;
}
