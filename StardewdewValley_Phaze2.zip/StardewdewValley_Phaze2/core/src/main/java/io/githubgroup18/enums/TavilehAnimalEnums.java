package io.githubgroup18.enums;

public enum TavilehAnimalEnums
{
    Cow,
    Sheep,
    Goat,
    Pig;
}
