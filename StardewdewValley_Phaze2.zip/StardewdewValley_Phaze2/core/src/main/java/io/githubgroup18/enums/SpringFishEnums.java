package io.githubgroup18.enums;

public enum SpringFishEnums
{
    Flounder,
    Lionfish,
    Herring,
    Ghostfish;
}
