package io.githubgroup18.enums;

public enum SummerWeatherEnums
{
    Sunny,
    Rain,
    Storm;
}
