package io.githubgroup18.enums;

public enum SummerLegendaryFishEnums
{
    Crimsonfish;
}
