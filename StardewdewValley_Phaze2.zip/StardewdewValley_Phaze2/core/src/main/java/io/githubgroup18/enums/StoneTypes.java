package io.githubgroup18.enums;

public enum StoneTypes {
    REGULAR,
    COPPER,
    IRON,
    GOLD,
    IRIDIUM;
}
