package io.githubgroup18.enums;

public enum AnimalProductType {
    NORMAL,
    ENHANCED // مثل تخم مرغ بزرگ، پای خرگوش
}
