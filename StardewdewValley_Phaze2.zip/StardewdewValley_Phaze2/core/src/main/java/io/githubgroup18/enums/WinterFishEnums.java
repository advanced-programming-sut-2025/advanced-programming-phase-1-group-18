package io.githubgroup18.enums;

public enum WinterFishEnums
{
    MidnightCarp,
    Squid,
    Tuna,
    Perch;
}
