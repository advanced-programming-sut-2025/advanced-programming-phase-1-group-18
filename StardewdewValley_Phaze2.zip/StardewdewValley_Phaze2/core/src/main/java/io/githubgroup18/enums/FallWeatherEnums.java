package io.githubgroup18.enums;

public enum FallWeatherEnums
{
    Sunny,
    Rain,
    Storm;
}
