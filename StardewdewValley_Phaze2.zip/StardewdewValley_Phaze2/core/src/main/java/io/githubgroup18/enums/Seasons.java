package io.githubgroup18.enums;

public enum Seasons {
    Spring,
    Summer,
    Fall,
    Winter;
}
