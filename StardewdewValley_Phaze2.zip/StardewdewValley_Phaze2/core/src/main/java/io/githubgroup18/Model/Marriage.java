package io.githubgroup18.Model;
public class Marriage
{

}
