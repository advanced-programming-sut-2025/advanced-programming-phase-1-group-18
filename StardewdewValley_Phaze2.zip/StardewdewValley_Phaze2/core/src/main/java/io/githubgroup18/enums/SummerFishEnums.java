package io.githubgroup18.enums;

public enum SummerFishEnums
{
    Tilapia,
    Dorado,
    Sunfish,
    RainbowTrout;
}
