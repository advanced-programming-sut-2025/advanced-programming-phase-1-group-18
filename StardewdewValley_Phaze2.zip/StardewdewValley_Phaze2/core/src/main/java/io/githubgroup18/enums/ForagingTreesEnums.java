package io.githubgroup18.enums;
import io.githubgroup18.Model.*;
public enum ForagingTreesEnums
{
    Acorns,
    MapleSeeds,
    PineCones,
    MahoganySeeds,
    MushroomTreeSeeds;
}
