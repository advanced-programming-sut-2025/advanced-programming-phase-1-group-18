package io.githubgroup18.enums;

public enum Quality {
    Normal,
    Silver,
    Gold,
    Iridium;
}
