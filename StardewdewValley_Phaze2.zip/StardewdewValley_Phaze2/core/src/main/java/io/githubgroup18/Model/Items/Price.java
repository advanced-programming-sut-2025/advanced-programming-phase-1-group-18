package io.githubgroup18.Model.Items;
public interface Price {
    public int getCorrectPrice();
}
