package io.githubgroup18.Model.Items;
public class Seed extends Item {

}
