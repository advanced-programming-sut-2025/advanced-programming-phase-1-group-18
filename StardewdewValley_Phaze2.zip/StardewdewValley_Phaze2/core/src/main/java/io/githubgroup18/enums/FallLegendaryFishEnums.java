package io.githubgroup18.enums;

public enum FallLegendaryFishEnums
{
    Angler;
}
