package io.githubgroup18.enums;

public enum TradeStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}
