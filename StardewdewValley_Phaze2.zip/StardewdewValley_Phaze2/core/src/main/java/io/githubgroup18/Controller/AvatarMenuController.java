package io.githubgroup18.Controller;


public class AvatarMenuController implements MenuEnter, ShowCurrentMenu {

    public void menuEnter(String menuName) {

    }

}
