package io.githubgroup18.enums;

public enum SkillEnum {
    FarmingSkill,
    MiningSkill,
    ForagingSkill,
    FishingSkill;
}
