package io.githubgroup18.enums;

public enum FallFishEnums
{
    Salmon,
    Sardine,
    Shad,
    BlueDiscus;


}
