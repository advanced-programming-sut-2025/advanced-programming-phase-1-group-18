package io.githubgroup18.enums;

public enum SpringLegendaryFishEnums
{
    Legend;
}
