package Controller;

import Model.App;
import Model.Result;
import enums.Menu;

public class JojaMartController implements MenuEnter, ShowCurrentMenu, MarketController {
    public void menuEnter(String menuName) {
        //from markets we can move to gamemenu
        menuName = menuName.toLowerCase();
        switch (menuName) {
            case "gamemenu":
                App.setCurrentMenu(Menu.GameMenu);
                System.out.println("You are now in GameMenu!");
                break;
            default:
                System.out.println("Invalid menu");
                break;
        }
    }
}
