package View;

import Controller.MarniesRanchController;
import Controller.PierresGeneralStoreController;
import enums.MarketMenuEnums;

import java.util.Scanner;

public class PirresGeneralStoreMenu extends AppMenu{
    private final PierresGeneralStoreController controller = new PierresGeneralStoreController();

    public void check(Scanner scanner) {
        String input = scanner.nextLine();
        if(MarketMenuEnums.SHOWALLPRODUCTS.getMather(input) != null) {

        }
        else if(MarketMenuEnums.SHOWALLAVAILABLEPRODUCTS.getMather(input) != null) {

        }
        else if(MarketMenuEnums.PURCHASE.getMather(input) != null) {

        }
        else if(MarketMenuEnums.CHEATADD.getMather(input) != null) {

        }
        else if(MarketMenuEnums.SELL.getMather(input) != null) {

        }
    }
}
