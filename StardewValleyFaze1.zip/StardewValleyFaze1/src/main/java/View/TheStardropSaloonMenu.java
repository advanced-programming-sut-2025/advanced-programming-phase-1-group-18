package View;

import Controller.PierresGeneralStoreController;
import Controller.TheStardropSaloonController;
import enums.MarketMenuEnums;

import java.util.Scanner;

public class TheStardropSaloonMenu extends AppMenu {
    private final TheStardropSaloonController controller = new TheStardropSaloonController();

    public void check(Scanner scanner) {
        String input = scanner.nextLine();
        if (MarketMenuEnums.SHOWALLPRODUCTS.getMather(input) != null) {

        } else if (MarketMenuEnums.SHOWALLAVAILABLEPRODUCTS.getMather(input) != null) {

        } else if (MarketMenuEnums.PURCHASE.getMather(input) != null) {

        } else if (MarketMenuEnums.CHEATADD.getMather(input) != null) {

        } else if (MarketMenuEnums.SELL.getMather(input) != null) {

        }
    }

}
