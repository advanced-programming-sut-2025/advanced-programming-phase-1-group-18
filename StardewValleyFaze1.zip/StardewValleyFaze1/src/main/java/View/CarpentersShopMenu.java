package View;

import Controller.BlackSmithController;
import Controller.CarpentersShopController;
import enums.MarketMenuEnums;

import java.util.Scanner;

public class CarpentersShopMenu extends AppMenu{
    private final CarpentersShopController controller = new CarpentersShopController();

    public void check(Scanner scanner) {
        String input = scanner.nextLine();
        if(MarketMenuEnums.SHOWALLPRODUCTS.getMather(input) != null) {

        }
        else if(MarketMenuEnums.SHOWALLAVAILABLEPRODUCTS.getMather(input) != null) {

        }
        else if(MarketMenuEnums.PURCHASE.getMather(input) != null) {

        }
        else if(MarketMenuEnums.CHEATADD.getMather(input) != null) {

        }
        else if(MarketMenuEnums.SELL.getMather(input) != null) {

        }
    }
}
