package enums;

public enum FallWeatherEnums
{
    Sunny,
    Rain,
    Storm;
}
