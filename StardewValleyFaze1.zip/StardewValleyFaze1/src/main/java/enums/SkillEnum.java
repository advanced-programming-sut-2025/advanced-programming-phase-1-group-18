package enums;

public enum SkillEnum {
    FarmingSkill,
    ExtractionSkill,
    ForagingSkill,
    FishingSkill;
}
