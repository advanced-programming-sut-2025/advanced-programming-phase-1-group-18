package Model;
import java.util.ArrayList;
public class Thor
{
    protected ArrayList<Cord> khordeh;

    public ArrayList<Cord> getKhordeh() {
        return khordeh;
    }

    public void setKhordeh(ArrayList<Cord> khordeh) {
        this.khordeh = khordeh;
    }
}



