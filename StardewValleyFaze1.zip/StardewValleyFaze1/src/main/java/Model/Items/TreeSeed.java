package Model.Items;

import enums.TreeSeedEnums;

public class TreeSeed extends Seed{

    TreeSeedEnums type;

    public TreeSeedEnums getType() {
        return type;
    }

    public void setType(TreeSeedEnums type) {
        this.type = type;
    }
}
