package enums;

public enum TradeStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}
