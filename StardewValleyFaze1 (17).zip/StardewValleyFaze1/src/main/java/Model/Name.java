package Model;

public interface Name {
    public String getCorrectName();
}
