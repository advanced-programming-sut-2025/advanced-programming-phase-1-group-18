package Model.Items;

import java.util.ArrayList;

public class Seed extends Source
{

}
